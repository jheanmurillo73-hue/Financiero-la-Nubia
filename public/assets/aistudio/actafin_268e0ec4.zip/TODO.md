# ActaFin · Resultados del producto

- [x] **Carga local y estados de procesamiento**
  - La aplicación permite seleccionar un archivo XLSM desde el computador.
  - El archivo se procesa íntegramente en el navegador, sin autenticación ni almacenamiento en servidores.
  - La interfaz muestra estados visibles para selección, carga, validación, procesamiento, resultado y error.

- [x] **Interpretación y validación de actas**
  - Se interpreta la hoja `Acta`, se detectan automáticamente Acta 1, Acta 2, Acta 3 hasta Acta N y se identifican los capítulos de obra.
  - Se validan hojas faltantes, campos inválidos, inconsistencias entre capítulos y costo directo, y actas no consecutivas.
  - Los mensajes de error y advertencia son claros y accionables.

- [x] **Cálculo financiero equivalente al resumen entregado**
  - Se calcula costo directo contratado y presupuesto bruto con administración, imprevistos, utilidad e IVA sobre utilidad.
  - Se calcula facturado bruto acumulado, factura neta acumulada, amortización de anticipo y retención de garantía.
  - Se calculan porcentajes de avance financiero general y por capítulo.
  - Se muestran controles contra el valor de factura reportado en el acta cuando está disponible.

- [x] **Dashboard de control de obra**
  - Se muestran indicadores resumen, selector por acta, tabla comparativa y gráficos de avance.
  - Se muestra explícitamente el porcentaje facturado y el porcentaje pendiente por facturar, junto con sus valores en COP.
  - Los valores se presentan en COP, con jerarquía visual y lectura responsive.

- [x] **Exportaciones**
  - Se puede descargar un informe XLSX con estructura equivalente a `Resumen`, `Capítulos` y `Datos`.
  - Se pueden descargar resultados en CSV y JSON cuando la estructura procesada lo permite.
