export type ParamKey =
  | 'administration'
  | 'contingencies'
  | 'utility'
  | 'ivaUtility'
  | 'advanceAmortization'
  | 'warrantyRetention'

export type FinancialParams = Record<ParamKey, number>

export type ActResult = {
  number: number
  directCost: number
  administration: number
  contingencies: number
  utility: number
  ivaUtility: number
  grossBilled: number
  amortization: number
  retention: number
  netInvoice: number
  reportedNet: number | null
  control: number | null
  grossPct: number
  grossCumulativePct: number
  netPct: number
  netCumulativePct: number
}

export type ChapterResult = {
  name: string
  contracted: number
  acts: number[]
  executedAccumulated: number
  progressPct: number
  balance: number
  sharePct: number
  lastAct: number
  previousAccumulated: number
}

export type ValidationMessage = {
  level: 'error' | 'warning'
  message: string
}

export type FinancialReport = {
  fileName: string
  title: string
  contract: string
  sourceSheet: string
  params: FinancialParams
  acts: ActResult[]
  chapters: ChapterResult[]
  directCostContracted: number
  grossBudget: number
  totalGrossBilled: number
  totalNetInvoice: number
  totalAmortization: number
  totalRetention: number
  grossProgressPct: number
  netProgressPct: number
  billedBalance: number
  validation: ValidationMessage[]
  parsedAt: string
}
