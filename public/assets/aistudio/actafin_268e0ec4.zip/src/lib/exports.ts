import * as XLSX from 'xlsx'
import type { FinancialReport } from './model'

const downloadBlob = (blob: Blob, fileName: string) => {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = fileName
  anchor.click()
  URL.revokeObjectURL(url)
}

const compactName = (fileName: string) => fileName.replace(/\.(xlsm|xlsx)$/i, '').replace(/[^a-z0-9áéíóúñ_-]+/gi, '_').slice(0, 54)

export const exportReportXlsx = (report: FinancialReport) => {
  const book = XLSX.utils.book_new()
  const parameters = [
    ['PARÁMETROS (tomados del acta)', 'Valor'],
    ['Administración', report.params.administration],
    ['Imprevistos', report.params.contingencies],
    ['Utilidad', report.params.utility],
    ['IVA sobre utilidad', report.params.ivaUtility],
    ['Amortización anticipo (s/ costo directo)', report.params.advanceAmortization],
    ['Retención garantía (s/ bruto con IVA)', report.params.warrantyRetention],
    [],
    ['INDICADORES', 'Valor'],
    ['Actas cargadas', report.acts.length],
    ['Costo directo contratado', report.directCostContracted],
    ['Presupuesto bruto', report.grossBudget],
    ['Facturado bruto acumulado', report.totalGrossBilled],
    ['% facturado bruto vs presupuesto', report.grossProgressPct],
    ['Saldo pendiente por facturar', Math.max(0, report.billedBalance)],
    ['% pendiente por facturar', Math.max(0, 1 - report.grossProgressPct)],
    ['Factura neta acumulada', report.totalNetInvoice],
    ['% facturado neto vs presupuesto', report.netProgressPct],
    ['Anticipo amortizado acumulado', -report.totalAmortization],
    ['Retención de garantía acumulada', -report.totalRetention],
    [],
    ['Acta', 'Costo directo', 'Administración', 'Imprevistos', 'Utilidad', 'IVA s/ utilidad', 'Facturado bruto', '(-) Amortización', '(-) Retención', 'Factura neta', '% acumulado bruto', '% acumulado neto', 'Neta reportada', 'Control'],
    ...report.acts.map((act) => [act.number, act.directCost, act.administration, act.contingencies, act.utility, act.ivaUtility, act.grossBilled, act.amortization, act.retention, act.netInvoice, act.grossCumulativePct, act.netCumulativePct, act.reportedNet, act.control]),
  ]
  const chapters = [
    ['AVANCE POR CAPÍTULO (costo directo, COP)'],
    [],
    ['Capítulo', 'Contratado', 'Ejecutado acumulado', '% avance', 'Saldo por ejecutar', '% del contrato', 'Ejecutado en la última acta', 'Acumulado acta anterior'],
    ...report.chapters.map((chapter) => [chapter.name, chapter.contracted, chapter.executedAccumulated, chapter.progressPct, chapter.balance, chapter.sharePct, chapter.lastAct, chapter.previousAccumulated]),
  ]
  const data = [
    ['DATOS FUENTE (generados por ActaFin – no editar a mano)'],
    [`Archivo fuente: ${report.fileName} | Actas cargadas: ${report.acts.length} | Valores en COP`],
    [],
    ['Concepto', 'Contrato', ...report.acts.map((act) => `Acta ${act.number}`)],
    ...report.chapters.map((chapter) => [chapter.name, chapter.contracted, ...chapter.acts]),
    ['Suma capítulos', report.chapters.reduce((sum, chapter) => sum + chapter.contracted, 0), ...report.acts.map((_, index) => report.chapters.reduce((sum, chapter) => sum + chapter.acts[index], 0))],
    ['Costo directo (reportado)', report.directCostContracted, ...report.acts.map((act) => act.directCost)],
    ['Administración (calculada)', report.directCostContracted * report.params.administration, ...report.acts.map((act) => act.administration)],
    ['Imprevistos (calculados)', report.directCostContracted * report.params.contingencies, ...report.acts.map((act) => act.contingencies)],
    ['Utilidad (calculada)', report.directCostContracted * report.params.utility, ...report.acts.map((act) => act.utility)],
    ['IVA sobre utilidad (calculado)', report.directCostContracted * report.params.utility * report.params.ivaUtility, ...report.acts.map((act) => act.ivaUtility)],
    ['Amortización anticipo (calculada)', -report.directCostContracted * report.params.advanceAmortization, ...report.acts.map((act) => act.amortization)],
    ['Retención de garantía (calculada)', -report.grossBudget * report.params.warrantyRetention, ...report.acts.map((act) => act.retention)],
    ['Valor factura neta (calculado)', report.grossBudget - report.directCostContracted * report.params.advanceAmortization - report.grossBudget * report.params.warrantyRetention, ...report.acts.map((act) => act.netInvoice)],
  ]
  const appendSheet = (rows: unknown[][], name: string, widths: number[]) => {
    const sheet = XLSX.utils.aoa_to_sheet(rows)
    sheet['!cols'] = widths.map((wch) => ({ wch }))
    XLSX.utils.book_append_sheet(book, sheet, name)
  }
  appendSheet(parameters, 'Resumen', [34, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18])
  appendSheet(chapters, 'Capítulos', [34, 18, 20, 14, 20, 15, 24, 22])
  appendSheet(data, 'Datos', [38, 18, ...report.acts.map(() => 18)])
  XLSX.writeFile(book, `Resumen_financiero_${compactName(report.fileName)}.xlsx`)
}

export const exportReportCsv = (report: FinancialReport) => {
  const rows = [
    ['Acta', 'Costo directo', 'Facturado bruto', 'Amortización', 'Retención', 'Factura neta', '% acumulado bruto', '% acumulado neto', 'Neta reportada', 'Control'],
    ...report.acts.map((act) => [act.number, act.directCost, act.grossBilled, act.amortization, act.retention, act.netInvoice, act.grossCumulativePct, act.netCumulativePct, act.reportedNet ?? '', act.control ?? '']),
  ]
  const csv = rows.map((row) => row.map((value) => JSON.stringify(value)).join(';')).join('\n')
  downloadBlob(new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' }), `actafin_${compactName(report.fileName)}.csv`)
}

export const exportReportJson = (report: FinancialReport) => {
  downloadBlob(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8' }), `actafin_${compactName(report.fileName)}.json`)
}
