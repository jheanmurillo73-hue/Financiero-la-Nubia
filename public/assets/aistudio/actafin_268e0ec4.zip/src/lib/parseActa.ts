import * as XLSX from 'xlsx'
import type {
  ActResult,
  ChapterResult,
  FinancialParams,
  FinancialReport,
  ParamKey,
  ValidationMessage,
} from './model'

const DEFAULT_PARAMS: FinancialParams = {
  administration: 0.09,
  contingencies: 0.01,
  utility: 0.06,
  ivaUtility: 0.19,
  advanceAmortization: 0.4,
  warrantyRetention: 0.05,
}

const normalize = (value: unknown) =>
  String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/\s+/g, ' ')
    .trim()

const asNumber = (value: unknown): number | null => {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (value instanceof Date) return null
  if (value === null || value === undefined || value === '') return null
  const raw = String(value).trim().replace(/\s/g, '').replace(/[$]/g, '')
  if (!raw) return null
  const colombian = /^-?[\d.]+,\d+$/.test(raw)
  const normalized = colombian
    ? raw.replace(/\./g, '').replace(',', '.')
    : raw.replace(/,/g, '')
  const result = Number(normalized)
  return Number.isFinite(result) ? result : null
}

const cell = (rows: unknown[][], row: number, col: number) => rows[row]?.[col] ?? null
const textAt = (rows: unknown[][], row: number, col: number) => String(cell(rows, row, col) ?? '').trim()
const amountAt = (rows: unknown[][], row: number, col: number) => asNumber(cell(rows, row, col)) ?? 0

const humanize = (value: string) =>
  value
    .toLowerCase()
    .replace(/(^|\s)\S/g, (letter) => letter.toUpperCase())
    .replace(/\bIva\b/g, 'IVA')
    .replace(/\bRetie\b/g, 'RETIE')

const findRows = (rows: unknown[][], matcher: (label: string) => boolean) => {
  const matches: number[] = []
  rows.forEach((row, index) => {
    const label = normalize(`${row?.[0] ?? ''} ${row?.[1] ?? ''}`)
    if (matcher(label)) matches.push(index)
  })
  return matches
}

const findFirstRow = (rows: unknown[][], matcher: (label: string) => boolean) => findRows(rows, matcher)[0] ?? -1

const readParams = (rows: unknown[][], messages: ValidationMessage[]) => {
  const params = { ...DEFAULT_PARAMS }
  const matches: Array<[ParamKey, RegExp, string]> = [
    ['administration', /\bADMINISTRACION\b/, 'Administración'],
    ['contingencies', /\bIMPREVISTOS\b/, 'Imprevistos'],
    ['utility', /\bUTILIDAD\b/, 'Utilidad'],
    ['ivaUtility', /\bIVA SOBRE UTILIDAD\b/, 'IVA sobre utilidad'],
    ['advanceAmortization', /\bAMORTIZACION\b/, 'Amortización'],
    ['warrantyRetention', /\bRETENCION DE GARANTIA\b/, 'Retención de garantía'],
  ]
  matches.forEach(([key, pattern, label]) => {
    const rowIndex = findFirstRow(rows, (row) => pattern.test(row) && !row.includes('TOTAL'))
    const found = rowIndex >= 0 ? asNumber(cell(rows, rowIndex, 4)) : null
    if (found !== null) {
      params[key] = found
    } else {
      messages.push({ level: 'warning', message: `No se detectó el parámetro ${label}; se usó ${DEFAULT_PARAMS[key] * 100}% como valor provisional.` })
    }
  })
  return params
}

const readActHeaders = (rows: unknown[][], messages: ValidationMessage[]) => {
  const found: Array<{ number: number; headerCol: number }> = []
  for (let row = 0; row < Math.min(rows.length, 8); row += 1) {
    for (let col = 0; col < (rows[row]?.length ?? 0); col += 1) {
      const match = normalize(cell(rows, row, col)).match(/\bACTA\s+NO\.?\s*(\d+)\b/)
      if (match) found.push({ number: Number(match[1]), headerCol: col })
    }
    if (found.length) break
  }
  const unique = [...new Map(found.map((item) => [item.number, item])).values()].sort((a, b) => a.number - b.number)
  if (!unique.length) {
    messages.push({ level: 'error', message: 'No se encontraron encabezados del tipo “ACTA No 1”, “ACTA No 2”… en la hoja Acta.' })
    return []
  }
  const expected = Array.from({ length: unique.length }, (_, index) => index + 1)
  const actual = unique.map((item) => item.number)
  if (actual.some((number, index) => number !== expected[index])) {
    messages.push({ level: 'error', message: `Las actas detectadas no son consecutivas: ${actual.join(', ')}.` })
  }
  return unique
}

const readChapters = (rows: unknown[][], actHeaders: Array<{ number: number; headerCol: number }>) => {
  const chapters: Array<{ name: string; contracted: number; acts: number[] }> = []
  const directRow = findFirstRow(rows, (label) => /\bCOSTO DIRECTO\b/.test(label))
  const sectionHeaders: Array<{ row: number; name: string }> = []
  for (let rowIndex = 6; rowIndex < (directRow >= 0 ? directRow : rows.length); rowIndex += 1) {
    const label = normalize(cell(rows, rowIndex, 1))
    const hasItemFields = [2, 3, 4].some((column) => cell(rows, rowIndex, column) !== null && cell(rows, rowIndex, column) !== '')
    if (label && !label.startsWith('SUBTOTAL ') && !hasItemFields && !/^(ACTA|CONDICIONES|CONTRATANTE|COSTO|ADMINISTRACION|IMPREVISTOS|UTILIDAD|IVA|AMORTIZACION|RETENCION|VALOR|SALDO|PARA CONSTANCIA)/.test(label)) {
      sectionHeaders.push({ row: rowIndex, name: label })
    }
  }
  sectionHeaders.forEach(({ row: startRow, name }) => {
    const endRow = rows.findIndex((candidate, index) => index > startRow && normalize(candidate?.[1]).startsWith('SUBTOTAL '))
    const stopRow = endRow > startRow ? endRow : rows.length
    const itemRows = rows.slice(startRow + 1, stopRow).filter((candidate) => asNumber(candidate?.[5]) !== null)
    const contracted = itemRows.reduce((sum, candidate) => sum + (asNumber(candidate?.[5]) ?? 0), 0)
    if (contracted <= 0) return
    chapters.push({
      name: humanize(name),
      contracted,
      acts: actHeaders.map(({ headerCol }) => itemRows.reduce((sum, candidate) => sum + amountAt([candidate], 0, headerCol + 1), 0)),
    })
  })
  const lastSubtotal = rows.reduce((last, row, index) => normalize(row?.[1]).startsWith('SUBTOTAL ') ? index : last, -1)
  const looseItems = rows.slice(lastSubtotal + 1, directRow >= 0 ? directRow : rows.length).filter((row) => Number.isInteger(asNumber(row?.[0])) && asNumber(row?.[5]) !== null && row?.[2])
  looseItems.forEach((row) => {
    chapters.push({
      name: humanize(String(row?.[1] ?? 'Partida sin capítulo')),
      contracted: asNumber(row?.[5]) ?? 0,
      acts: actHeaders.map(({ headerCol }) => amountAt([row], 0, headerCol + 1)),
    })
  })
  return chapters
}

const sourceAmounts = (rows: unknown[][], rowIndex: number, actHeaders: Array<{ number: number; headerCol: number }>) =>
  rowIndex >= 0 ? actHeaders.map(({ headerCol }) => amountAt(rows, rowIndex, headerCol + 1)) : []

const deriveReport = (rows: unknown[][], fileName: string, messages: ValidationMessage[]): FinancialReport => {
  const actHeaders = readActHeaders(rows, messages)
  const params = readParams(rows, messages)
  const chaptersRaw = readChapters(rows, actHeaders)
  if (!chaptersRaw.length) messages.push({ level: 'error', message: 'No se encontraron filas SUBTOTAL con capítulos y valores contratados.' })

  const directRow = findFirstRow(rows, (label) => /\bCOSTO DIRECTO\b/.test(label))
  const contingenciesRow = findFirstRow(rows, (label) => /^IMPREVISTOS$/.test(label))
  const reportedInvoiceRow = findFirstRow(rows, (label) => label.includes('VALOR FACTURA'))
  const directFromSheet = directRow >= 0 ? asNumber(cell(rows, directRow, 5)) : null
  const chapterContracted = chaptersRaw.reduce((sum, chapter) => sum + chapter.contracted, 0)
  const contingenciesFromSheet = contingenciesRow >= 0 ? amountAt(rows, contingenciesRow, 5) : 0
  const contingenciesContracted = contingenciesFromSheet || Math.max(0, (directFromSheet ?? chapterContracted) - chapterContracted)
  const directCostContracted = directFromSheet ?? chapterContracted + contingenciesContracted
  const chapterActs = actHeaders.map((_, actIndex) => chaptersRaw.reduce((sum, chapter) => sum + (chapter.acts[actIndex] ?? 0), 0))
  const contingenciesActs = sourceAmounts(rows, contingenciesRow, actHeaders)
  const directActsFromSheet = sourceAmounts(rows, directRow, actHeaders)
  const directCostActs = actHeaders.map((_, index) => directActsFromSheet[index] || chapterActs[index] + (contingenciesActs[index] ?? 0))
  const reportedNet = sourceAmounts(rows, reportedInvoiceRow, actHeaders)
  const grossBudget = directCostContracted * (1 + params.administration + params.contingencies + params.utility + params.utility * params.ivaUtility)

  const acts: ActResult[] = []
  let grossAccumulated = 0
  let netAccumulated = 0
  actHeaders.forEach(({ number }, index) => {
    const directCost = directCostActs[index] ?? 0
    const administration = directCost * params.administration
    const contingencies = directCost * params.contingencies
    const utility = directCost * params.utility
    const ivaUtility = utility * params.ivaUtility
    const grossBilled = directCost + administration + contingencies + utility + ivaUtility
    const amortization = -directCost * params.advanceAmortization
    const retention = -grossBilled * params.warrantyRetention
    const netInvoice = grossBilled + amortization + retention
    grossAccumulated += grossBilled
    netAccumulated += netInvoice
    const reported = reportedNet[index] ?? null
    acts.push({
      number,
      directCost,
      administration,
      contingencies,
      utility,
      ivaUtility,
      grossBilled,
      amortization,
      retention,
      netInvoice,
      reportedNet: reported,
      control: reported === null ? null : netInvoice - reported,
      grossPct: grossBudget ? grossBilled / grossBudget : 0,
      grossCumulativePct: grossBudget ? grossAccumulated / grossBudget : 0,
      netPct: grossBudget ? netInvoice / grossBudget : 0,
      netCumulativePct: grossBudget ? netAccumulated / grossBudget : 0,
    })
  })

  const chapters: ChapterResult[] = chaptersRaw.map((chapter) => {
    const executedAccumulated = chapter.acts.reduce((sum, value) => sum + value, 0)
    const lastAct = chapter.acts.at(-1) ?? 0
    return {
      ...chapter,
      executedAccumulated,
      progressPct: chapter.contracted ? executedAccumulated / chapter.contracted : 0,
      balance: chapter.contracted - executedAccumulated,
      sharePct: directCostContracted ? chapter.contracted / directCostContracted : 0,
      lastAct,
      previousAccumulated: executedAccumulated - lastAct,
    }
  })

  if (directRow < 0) messages.push({ level: 'warning', message: 'No se encontró la fila COSTO DIRECTO; se reconstruyó sumando capítulos e imprevistos.' })
  if (actHeaders.length && directCostActs.every((value) => value === 0)) messages.push({ level: 'warning', message: 'Las actas fueron detectadas, pero sus valores de ejecución están vacíos o en cero.' })
  const chapterTotal = chapters.reduce((sum, chapter) => sum + chapter.contracted, 0) + contingenciesContracted
  const expectedContingenciesGap = Math.abs(directCostContracted * params.contingencies)
  if (Math.abs(chapterTotal - directCostContracted) > Math.max(1, expectedContingenciesGap * 1.5)) {
    messages.push({ level: 'warning', message: `Control de contrato: la suma de capítulos e imprevistos difiere del costo directo en ${formatNumber(Math.abs(chapterTotal - directCostContracted))} COP.` })
  }

  const title = textAt(rows, 1, 3) || 'Informe financiero de actas parciales'
  const contract = textAt(rows, 0, 5) || textAt(rows, 0, 3) || 'Contrato no identificado'
  const totalGrossBilled = acts.reduce((sum, act) => sum + act.grossBilled, 0)
  const totalNetInvoice = acts.reduce((sum, act) => sum + act.netInvoice, 0)
  const totalAmortization = acts.reduce((sum, act) => sum + act.amortization, 0)
  const totalRetention = acts.reduce((sum, act) => sum + act.retention, 0)
  return {
    fileName,
    title,
    contract,
    sourceSheet: 'Acta',
    params,
    acts,
    chapters,
    directCostContracted,
    grossBudget,
    totalGrossBilled,
    totalNetInvoice,
    totalAmortization,
    totalRetention,
    grossProgressPct: grossBudget ? totalGrossBilled / grossBudget : 0,
    netProgressPct: grossBudget ? totalNetInvoice / grossBudget : 0,
    billedBalance: grossBudget - totalGrossBilled,
    validation: messages,
    parsedAt: new Date().toISOString(),
  }
}

export const parseActaWorkbook = (buffer: ArrayBuffer, fileName: string): FinancialReport => {
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true, raw: true, cellFormula: false })
  const messages: ValidationMessage[] = []
  if (!workbook.SheetNames.includes('Acta')) {
    return {
      fileName,
      title: 'No fue posible generar el informe',
      contract: '—',
      sourceSheet: 'Acta',
      params: { ...DEFAULT_PARAMS },
      acts: [],
      chapters: [],
      directCostContracted: 0,
      grossBudget: 0,
      totalGrossBilled: 0,
      totalNetInvoice: 0,
      totalAmortization: 0,
      totalRetention: 0,
      grossProgressPct: 0,
      netProgressPct: 0,
      billedBalance: 0,
      validation: [{ level: 'error', message: 'El archivo no contiene la hoja obligatoria “Acta”.' }],
      parsedAt: new Date().toISOString(),
    }
  }
  const rows = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets.Acta, { header: 1, raw: true, defval: null })
  return deriveReport(rows, fileName, messages)
}

const formatNumber = (value: number) => new Intl.NumberFormat('es-CO', { maximumFractionDigits: 0 }).format(value)
