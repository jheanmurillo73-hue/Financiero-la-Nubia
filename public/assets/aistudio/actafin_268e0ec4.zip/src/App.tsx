import { useMemo, useRef, useState } from 'react'
import {
  ArrowDownToLine,
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronRight,
  CircleAlert,
  CloudOff,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  Table2,
  Upload,
  X,
} from 'lucide-react'
import { exportReportCsv, exportReportJson, exportReportXlsx } from './lib/exports'
import { parseActaWorkbook } from './lib/parseActa'
import type { ActResult, ChapterResult, FinancialReport } from './lib/model'
import './styles.css'

type AppStatus = 'empty' | 'reading' | 'ready' | 'error'

const currency = (value: number | null | undefined) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '—'
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(value)
}

const number = (value: number | null | undefined) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '—'
  return new Intl.NumberFormat('es-CO', { maximumFractionDigits: 0 }).format(value)
}

const percent = (value: number | null | undefined) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '—'
  return new Intl.NumberFormat('es-CO', { style: 'percent', maximumFractionDigits: 1 }).format(value)
}

const compact = (value: number) => {
  const absolute = Math.abs(value)
  if (absolute >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(1).replace('.', ',')}B`
  if (absolute >= 1_000_000) return `${(value / 1_000_000).toFixed(1).replace('.', ',')}M`
  if (absolute >= 1_000) return `${(value / 1_000).toFixed(0)}K`
  return `${Math.round(value)}`
}

const shortFileName = (name: string) => (name.length > 48 ? `${name.slice(0, 32)}…${name.slice(-13)}` : name)

function StatusPill({ status }: { status: AppStatus }) {
  const labels: Record<AppStatus, string> = {
    empty: 'Esperando archivo',
    reading: 'Procesando localmente',
    ready: 'Informe listo',
    error: 'Revisar archivo',
  }
  return <span className={`status-pill status-${status}`}><span className="status-dot" />{labels[status]}</span>
}

function KpiCard({ label, value, helper, accent = '' }: { label: string; value: string; helper: string; accent?: string }) {
  return <article className={`kpi-card ${accent}`}>
    <div className="kpi-label">{label}</div>
    <div className="kpi-value">{value}</div>
    <div className="kpi-helper">{helper}</div>
  </article>
}

function ProgressChart({ report }: { report: FinancialReport }) {
  const max = Math.max(report.grossProgressPct, 0.01)
  return <div className="chart-wrap">
    <div className="chart-legend"><span><i className="legend-dot gross" />Avance bruto acumulado</span><span><i className="legend-dot net" />Avance neto acumulado</span></div>
    <div className="progress-chart" aria-label="Avance acumulado por acta">
      {report.acts.map((act) => <div className="chart-column" key={act.number}>
        <div className="bar-pair">
          <div className="chart-bar gross" style={{ height: `${Math.max(8, (act.grossCumulativePct / max) * 100)}%` }} title={`Bruto ${percent(act.grossCumulativePct)}`}><span>{percent(act.grossCumulativePct)}</span></div>
          <div className="chart-bar net" style={{ height: `${Math.max(8, (act.netCumulativePct / max) * 100)}%` }} title={`Neto ${percent(act.netCumulativePct)}`}><span>{percent(act.netCumulativePct)}</span></div>
        </div>
        <strong>Acta {act.number}</strong>
      </div>)}
    </div>
    <div className="chart-baseline"><span>0%</span><span>Presupuesto bruto · {currency(report.grossBudget)}</span><span>100%</span></div>
  </div>
}

function ActTable({ acts }: { acts: ActResult[] }) {
  return <div className="table-scroll">
    <table className="data-table act-table">
      <thead><tr><th>Acta</th><th>Costo directo</th><th>Facturado bruto</th><th>Amortización</th><th>Retención</th><th>Factura neta</th><th>Control</th></tr></thead>
      <tbody>{acts.map((act) => <tr key={act.number}>
        <td><span className="act-tag">{String(act.number).padStart(2, '0')}</span></td>
        <td>{currency(act.directCost)}</td>
        <td>{currency(act.grossBilled)}</td>
        <td className="negative">{currency(act.amortization)}</td>
        <td className="negative">{currency(act.retention)}</td>
        <td className="strong-cell">{currency(act.netInvoice)}</td>
        <td className={act.control !== null && Math.abs(act.control) > 2 ? 'warning-cell' : 'ok-cell'}>{act.control === null ? 'No reportado' : currency(act.control)}</td>
      </tr>)}</tbody>
    </table>
  </div>
}

function ChapterTable({ chapters, selectedAct }: { chapters: ChapterResult[]; selectedAct: number }) {
  return <div className="table-scroll">
    <table className="data-table chapter-table">
      <thead><tr><th>Capítulo</th><th>Contratado</th><th>Acumulado</th><th>Avance</th><th>Saldo</th><th>Acta {selectedAct}</th><th>Peso contrato</th></tr></thead>
      <tbody>{chapters.map((chapter) => <tr key={chapter.name}>
        <td><div className="chapter-name">{chapter.name}</div><div className="row-progress"><span style={{ width: `${Math.min(100, Math.max(0, chapter.progressPct * 100))}%` }} /></div></td>
        <td>{currency(chapter.contracted)}</td>
        <td>{currency(chapter.executedAccumulated)}</td>
        <td><span className="progress-value">{percent(chapter.progressPct)}</span></td>
        <td>{currency(chapter.balance)}</td>
        <td>{currency(chapter.acts[selectedAct - 1] ?? 0)}</td>
        <td>{percent(chapter.sharePct)}</td>
      </tr>)}</tbody>
    </table>
  </div>
}

function App() {
  const [report, setReport] = useState<FinancialReport | null>(null)
  const [status, setStatus] = useState<AppStatus>('empty')
  const [fileName, setFileName] = useState('')
  const [selectedAct, setSelectedAct] = useState(0)
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const processFile = async (file: File) => {
    setFileName(file.name)
    setStatus('reading')
    try {
      const buffer = await file.arrayBuffer()
      await new Promise((resolve) => window.setTimeout(resolve, 80))
      const parsed = parseActaWorkbook(buffer, file.name)
      setReport(parsed)
      setSelectedAct(parsed.acts[parsed.acts.length - 1]?.number ?? 0)
      setStatus(parsed.validation.some((message) => message.level === 'error') ? 'error' : 'ready')
    } catch (error) {
      setReport(null)
      setStatus('error')
      console.error(error)
    }
  }

  const selected = useMemo(() => report?.acts.find((act) => act.number === selectedAct) ?? report?.acts[report.acts.length - 1], [report, selectedAct])
  const errors = report?.validation.filter((item) => item.level === 'error') ?? []
  const warnings = report?.validation.filter((item) => item.level === 'warning') ?? []

  const onInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) void processFile(file)
  }

  const reset = () => {
    setReport(null)
    setFileName('')
    setSelectedAct(0)
    setStatus('empty')
    if (inputRef.current) inputRef.current.value = ''
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-lockup"><div className="brand-mark">AF</div><div><div className="brand-name">ActaFin</div><div className="brand-subtitle">control financiero de obra</div></div></div>
      <div className="topbar-right"><div className="privacy-note"><LockKeyhole size={14} /> Procesamiento local</div><StatusPill status={status} /></div>
    </header>

    <main className="main-content">
      <section className="hero-section">
        <div className="eyebrow"><span className="eyebrow-line" /> INFORME FINANCIERO · ACTAS PARCIALES</div>
        <div className="hero-grid">
          <div><h1>De archivo de obra a <em>lectura ejecutiva.</em></h1><p className="hero-copy">Carga el consolidado de avance, valida su estructura y convierte cada acta en una vista financiera clara para decidir con datos.</p></div>
          <div className="hero-side-note"><span className="note-index">01</span><span>La información permanece en este navegador.<br />Nada se sube a un servidor.</span></div>
        </div>
      </section>

      {!report && <section className={`upload-card ${dragging ? 'dragging' : ''}`} onDragEnter={(event) => { event.preventDefault(); setDragging(true) }} onDragOver={(event) => event.preventDefault()} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); const file = event.dataTransfer.files[0]; if (file) void processFile(file) }}>
        <div className="upload-icon"><Upload size={24} /></div>
        <div className="upload-copy"><h2>{status === 'reading' ? 'Procesando el archivo…' : 'Carga tu archivo de avance'}</h2><p>Arrástralo aquí o selecciónalo desde tu computador. Recomendado: <strong>.XLSM</strong> con la hoja <strong>Acta</strong>.</p></div>
        <button className="primary-button" onClick={() => inputRef.current?.click()} disabled={status === 'reading'}><FolderOpen size={17} /> Seleccionar archivo</button>
        <input ref={inputRef} className="sr-only" type="file" accept=".xlsm,.xlsx,application/vnd.ms-excel.sheet.macroEnabled.12,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={onInput} />
        <div className="upload-footer"><span><ShieldCheck size={15} /> Se procesa localmente</span><span><FileSpreadsheet size={15} /> XLSM / XLSX</span><span><RefreshCw size={15} /> Acta 1 → Acta N</span></div>
      </section>}

      {status === 'error' && !report && <div className="error-banner"><CircleAlert size={18} /><div><strong>No pudimos leer el archivo.</strong><span>Verifica que sea un libro Excel válido y vuelve a intentarlo.</span></div></div>}

      {report && <>
        <section className="source-strip">
          <div className="source-file"><div className="file-icon"><FileSpreadsheet size={18} /></div><div><span className="source-label">Archivo analizado</span><strong title={fileName}>{shortFileName(fileName)}</strong></div></div>
          <div className="source-stats"><span><b>{report.acts.length}</b> actas</span><span><b>{report.chapters.length}</b> capítulos</span><span><b>{report.sourceSheet}</b> interpretada</span></div>
          <button className="ghost-button" onClick={reset}><X size={16} /> Cambiar archivo</button>
        </section>

        {errors.length > 0 && <div className="message-stack">{errors.map((message) => <div className="message error" key={message.message}><CircleAlert size={17} /><span>{message.message}</span></div>)}</div>}
        {warnings.length > 0 && <div className="message-stack">{warnings.map((message) => <div className="message warning" key={message.message}><CircleAlert size={17} /><span>{message.message}</span></div>)}</div>}

        <section className="report-heading"><div><div className="eyebrow compact-eyebrow"><span className="eyebrow-line" /> RESULTADO DEL PROCESAMIENTO</div><h2>{report.title}</h2><p>{report.contract}</p></div><div className="export-actions"><button className="primary-button" onClick={() => exportReportXlsx(report)}><ArrowDownToLine size={16} /> Descargar XLSX</button><button className="outline-button" onClick={() => exportReportCsv(report)}>CSV</button><button className="outline-button" onClick={() => exportReportJson(report)}>JSON</button></div></section>

        <section className="kpi-grid">
          <KpiCard label="Avance bruto" value={percent(report.grossProgressPct)} helper={`${currency(report.totalGrossBilled)} facturado`} accent="accent-gold" />
          <KpiCard label="Avance neto" value={percent(report.netProgressPct)} helper={`${currency(report.totalNetInvoice)} por pagar acumulado`} accent="accent-green" />
          <KpiCard label="Costo directo" value={currency(report.directCostContracted)} helper={`Presupuesto bruto ${currency(report.grossBudget)}`} accent="accent-blue" />
          <KpiCard label="Saldo por facturar" value={currency(report.billedBalance)} helper={`${percent(1 - report.grossProgressPct)} del presupuesto bruto`} accent="accent-violet" />
        </section>

        <section className="billing-summary panel">
          <div className="billing-summary-head"><div><span className="panel-kicker">LECTURA DE FACTURACIÓN</span><h3>¿Cuánto se ha facturado y cuánto queda pendiente?</h3></div><span className="billing-total">Presupuesto bruto <strong>{currency(report.grossBudget)}</strong></span></div>
          <div className="billing-meter" aria-label={`Facturado ${percent(report.grossProgressPct)} y pendiente ${percent(1 - report.grossProgressPct)}`}><span style={{ width: `${Math.min(100, Math.max(0, report.grossProgressPct * 100))}%` }} /></div>
          <div className="billing-values"><div className="billing-value billed"><span className="billing-dot" /><div><strong>{percent(report.grossProgressPct)}</strong><span>Facturado</span><small>{currency(report.totalGrossBilled)} acumulado</small></div></div><div className="billing-value pending"><span className="billing-dot" /><div><strong>{percent(Math.max(0, 1 - report.grossProgressPct))}</strong><span>Pendiente por facturar</span><small>{currency(Math.max(0, report.billedBalance))} de saldo</small></div></div></div>
        </section>

        <section className="detail-grid">
          <article className="panel chart-panel"><div className="panel-heading"><div><span className="panel-kicker">EVOLUCIÓN</span><h3>Avance acumulado</h3></div><BarChart3 size={19} /></div><ProgressChart report={report} /></article>
          <article className="panel act-focus-panel"><div className="panel-heading"><div><span className="panel-kicker">CORTE SELECCIONADO</span><h3>Acta {selected?.number ?? '—'}</h3></div><span className="focus-badge"><ArrowUpRight size={14} /> {selected ? percent(selected.grossCumulativePct) : '—'}</span></div>{selected && <div className="focus-content"><div className="focus-main-value">{currency(selected.netInvoice)}</div><div className="focus-caption">Factura neta del corte</div><div className="focus-metrics"><div><span>Directo ejecutado</span><strong>{currency(selected.directCost)}</strong></div><div><span>Facturado bruto</span><strong>{currency(selected.grossBilled)}</strong></div><div><span>Amortización</span><strong className="negative">{currency(selected.amortization)}</strong></div><div><span>Retención</span><strong className="negative">{currency(selected.retention)}</strong></div></div></div>}</article>
        </section>

        <section className="panel acts-panel"><div className="panel-heading"><div><span className="panel-kicker">TRAZABILIDAD</span><h3>Resumen por acta</h3></div><div className="tab-list">{report.acts.map((act) => <button className={act.number === selectedAct ? 'active' : ''} key={act.number} onClick={() => setSelectedAct(act.number)}>Acta {act.number}</button>)}</div></div><ActTable acts={report.acts} /></section>

        <section className="panel chapters-panel"><div className="panel-heading"><div><span className="panel-kicker">EJECUCIÓN DEL CONTRATO</span><h3>Avance por capítulo</h3></div><div className="panel-meta"><Table2 size={16} /> {report.chapters.length} capítulos detectados</div></div><ChapterTable chapters={report.chapters} selectedAct={selectedAct || report.acts.length} /></section>

        <section className="bottom-grid"><article className="panel params-panel"><div className="panel-heading"><div><span className="panel-kicker">REGLAS DEL INFORME</span><h3>Parámetros financieros</h3></div><ChevronRight size={18} /></div><div className="params-list"><div><span>Administración</span><b>{percent(report.params.administration)}</b></div><div><span>Imprevistos</span><b>{percent(report.params.contingencies)}</b></div><div><span>Utilidad</span><b>{percent(report.params.utility)}</b></div><div><span>IVA sobre utilidad</span><b>{percent(report.params.ivaUtility)}</b></div><div><span>Amortización anticipo</span><b>{percent(report.params.advanceAmortization)}</b></div><div><span>Retención garantía</span><b>{percent(report.params.warrantyRetention)}</b></div></div></article><article className="panel trust-panel"><div className="trust-visual"><CloudOff size={28} /></div><div><span className="panel-kicker">PRIVACIDAD DE LOS DATOS</span><h3>Tu información no sale de aquí.</h3><p>ActaFin calcula y arma las exportaciones directamente en tu navegador. No se guardan libros ni resultados en un servidor.</p><div className="trust-check"><Check size={15} /> Sin autenticación</div><div className="trust-check"><Check size={15} /> Sin base de datos</div></div></article></section>

        <footer className="report-footer"><span><FileText size={14} /> Informe generado {new Date(report.parsedAt).toLocaleString('es-CO', { dateStyle: 'medium', timeStyle: 'short' })}</span><span>ActaFin · lectura financiera de obra</span></footer>
      </>}

      {!report && <section className="empty-guidance"><div className="guidance-item"><span className="guidance-number">01</span><div><strong>Selecciona</strong><span>Tu consolidado XLSM</span></div></div><div className="guidance-arrow">→</div><div className="guidance-item"><span className="guidance-number">02</span><div><strong>Validamos</strong><span>Actas, capítulos y parámetros</span></div></div><div className="guidance-arrow">→</div><div className="guidance-item"><span className="guidance-number">03</span><div><strong>Descarga</strong><span>Tu resumen financiero</span></div></div></section>}
    </main>
    <footer className="app-footer"><span>Construido para equipos de obra que necesitan ver el número detrás del avance.</span><span>v0.1 · procesamiento local</span></footer>
  </div>
}

export default App
