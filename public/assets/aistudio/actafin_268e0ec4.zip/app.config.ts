export default {
  logoUrl: "https://placehold.co/64x64/0b1724/f4b85f.png?text=A",
}
